import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

/**
 * 
 */

/**
 * @author Alvin
 * Date: May 2023
 * Description:
 * This class is the game portion of the UI
 * Method List:
 * + void mouseClicked(MouseEvent e)	| Gets called when the mouse button is clicked
 * + void mousePressed(MouseEvent e)	| Gets called when the mouse button is pressed
 * + void mouseReleased(MouseEvent e)	| Gets called when the mouse button is released
 * + void mouseEntered(MouseEvent e)	| Gets called when the cursor moves into frame
 * + void mouseExited(MouseEvent e)	| Gets called when the cursor leaves the frame
 * + void movePiece(int sourceTile, int destinationTile)	| Moves piece at a tile to a set tile
 * + void movePiece(int piece, int destinationTile) | method to visually and logically move a piece
 * + void checkValid(int tile) | method to control turn and piece focusing
 * + public void promote(int piece) | method to promote pawn
 * + ImageIcon getImage(String filename) | returns the image file with a folder from the source
 * + static void main(String[] args)	| Self Testing
 * Resources:
 * - https://docs.oracle.com/javase/tutorial/uiswing/events/mouselistener.html
 */
public class Chess extends JFrame implements MouseListener {

	// Attributes
	private ImagePicture board, pieceImgs[], possibleMoves[];
	private Logic logic;
	private int focus, moves[];
	private char turn;
	private boolean pawnChange;
	private boolean debug = true;

	/**
	 * Default constructor
	 */
	public Chess() {
		// call parent default constructor
		super();
		// set the background
		try {
			board = new ImagePicture(getImage("ChessBoard.png"));
		}
		catch (Exception e) {}
		board.setBounds(getBounds());
		// set window size to fit the background
		setSize(board.getmyWidth(), board.getmyHeight());
		// initialise attributes
		setLogic(new Logic());
		pieceImgs = new ImagePicture[32];
		focus = -1;
		turn = 'w';
		pawnChange = false;
		possibleMoves = new ImagePicture[0];
		// add piece images
		for(int i = 0; i < 32; i++) {
			// set the piece image and its placement
			pieceImgs[i] = new ImagePicture(getImage(logic.getFilename(i)), logic.getPieces()[i].getTile()%8*50+200, logic.getPieces()[i].getTile()/8*50+100);
			// add the image
			add(pieceImgs[i]);
			// show the image anywhere
			pieceImgs[i].setBounds(getBounds());
		}
		// add the background
		add(board);
		// add mouse listener
		addMouseListener(this);
		// show window
		setVisible(true);
		// make window not resizable
		setResizable(false);
		// properly end program when x is pressed
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	//>>>>Getters/Setters>>>>
	/**
	 * @return the pawnChange
	 */
	public boolean isPawnChange() {
		return pawnChange;
	}


	/**
	 * @param pawnChange the pawnChange to set
	 */
	public void setPawnChange(boolean pawnChange) {
		this.pawnChange = pawnChange;
	}

	/**
	 * @return the focus
	 */
	public int getFocus() {
		return focus;
	}

	/**
	 * @param focus the focus to set
	 */
	public void setFocus(int focus) {
		this.focus = focus;
	}

	/**
	 * @return the moves
	 */
	public int[] getMoves() {
		return moves;
	}

	/**
	 * @param moves the moves to set
	 */
	public void setMoves(int[] moves) {
		this.moves = moves;
	}

	/**
	 * @return the logic
	 */
	public Logic getLogic() {
		return logic;
	}

	/**
	 * @param logic the logic to set
	 */
	public void setLogic(Logic logic) {
		this.logic = logic;
	}
	//>>>>End Getters/Setters>>>>

	//>>>>Mouse Listener>>>>
	@Override
	public void mouseClicked(MouseEvent e) {
		if(pawnChange) { // check is pawn is being promoted
			// continue is mouse is in valid location
			if(e.getX() >= pieceImgs[focus].getxPos() + 5 && e.getX() < pieceImgs[focus].getxPos() + 205 && e.getY() >= pieceImgs[focus].getyPos() + 35 && e.getY() < pieceImgs[focus].getyPos() + 85) {
				// declare and initialise variable for piece selection
				int newPiece = (e.getX() - pieceImgs[focus].getxPos() - 5)/50;
				// use piece selection variable to change type
				switch(newPiece) {
				case 0:{ // change pawn to knight
					logic.getPieces()[focus].setType("knight");
					break;
				}
				case 1:{ // change pawn to rook
					logic.getPieces()[focus].setType("rook");
					break;
				}
				case 2:{ // change pawn to bishop
					logic.getPieces()[focus].setType("bishop");
					break;
				}
				default:{ // change pawn to queen
					logic.getPieces()[focus].setType("queen");
				}
				}
				// update piece image to new type
				pieceImgs[focus].setImage(getImage(logic.getFilename(focus)));
				// update piece image location
				pieceImgs[focus].setxPos(logic.getPieces()[focus].getTile()%8*50+200);
				pieceImgs[focus].setyPos(logic.getPieces()[focus].getTile()/8*50+100);
				// turn off pawn promotion variable
				this.pawnChange = false;
				// set focus piece to invalid
				focus = -1;
			}
		}
		// continue if the mouse was clicked within the board
		else if((e.getX()>=205 && e.getY()>=130) && (e.getX()<605 && e.getY()<530)) {
			// remove any green squares
			for(int i = 0; i < possibleMoves.length; i++) {
				remove(possibleMoves[i]); // remove the green squares
			}
			/* calculate the tile the cursor clicked
			 * [00][01][02][03][04][05][06][07]
			 * [08][09][10][11][12][13][14][15]
			 * [16][17][18][19][20][21][22][23]
			 * [24][25][26][27][28][29][30][31]
			 * [32][33][34][35][36][37][38][39]
			 * [40][41][42][43][44][45][46][47]
			 * [48][49][50][51][52][53][54][55]
			 * [56][57][58][59][60][61][62][63]
			 */
			// calculate clicked tile
			int tile = (e.getX()-205)/50 + (e.getY()-130)/50*8;
			// do if the selected tile is empty, no piece is focused, and either the selected piece's 
			// team is the same as the current turn or debug is on
			if(logic.pieceAtTile(tile) > -1 && focus < 0 && (logic.getPieces()[logic.pieceAtTile(tile)].getTeam() == turn || debug)) {
				// set the focus to the piece at the selected tile
				focus = logic.pieceAtTile(tile);
				// if the focus is a valid number
				if(focus > -1) {
					// get possible moves from the selected piece
					String moves[] = logic.getMoves(focus);
					// do if the piece has possible moves
					if(moves.length > 0 && moves[0] != "") {
						// set moves attribute to an integer array of equal length to the moves array
						this.moves = new int[moves.length];
						// set possible moves attribute to an ImagePicure array of equal length to the moves array
						possibleMoves = new ImagePicture[moves.length];
						// for every index of the moves attribute, add the possible moves as an integer, set every element of 
						// the ImagePicture array to a new image, make the image visible anywhere in the frame, add the image 
						// to the frame, and show each image
						for(int i = 0; i < moves.length && !moves[0].equals(""); i++) {
							this.moves[i] = Integer.parseInt(moves[i]);
							possibleMoves[i] = new ImagePicture(getImage("can.png"), Integer.parseInt(moves[i])%8*50+200, Integer.parseInt(moves[i])/8*50+100);
							possibleMoves[i].setBounds(getBounds());
							add(possibleMoves[i]);
							setVisible(true);
						}
					}
					else {
						// remove focus if there aren't any valid moves
						focus = -1;
					}
				}
			}
			else if(focus > -1) { // if a piece is focused on
				checkValid(tile);
			}
		}
		// remove and add the board to print it below
		remove(board);
		add(board);
		// update the frame
		repaint();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void movePiece(int piece, int destinationTile) {
		// visually remove piece at new tile if it's taken
		if(logic.pieceAtTile(destinationTile) > -1) {
			int oldPiece = logic.pieceAtTile(destinationTile);
			remove(pieceImgs[oldPiece]);
			logic.getPieces()[oldPiece].setTile(-1);
		}

		// logically and visually remove old tile
		logic.getPieces()[piece].setHasMoved(true);
		logic.getPieces()[piece].setTile(destinationTile);
		// logically and visually update new tile
		// declare and initialise variable to save the piece data to an object
		Piece pieceObj = logic.getPieces()[piece];
		pieceImgs[piece].setxPos(destinationTile%8*50+200);
		pieceImgs[piece].setyPos(destinationTile/8*50+100);
		// check if the piece is a pawn
		if(logic.getPieces()[piece].getType().equalsIgnoreCase("pawn")) {
			// depending on its team, check if it matches a certain row
			// if the row matches, promote the pawn
			if(pieceObj.getTeam() == 'b') {
				if(pieceObj.getTile()/8 == 7) {
					promote(piece);
				}
			}
			else {
				if(pieceObj.getTile()/8 == 0) {
					promote(piece);
				}
			}
		}
		// update the ui
		repaint();
	}
	//>>>>End Mouse Listener>>>>

	/**
	 * Method to check if the selected tile is a valid move
	 */
	public void checkValid(int tile) {
		for(int i = 0; i < this.moves.length; i++) { // check all of the focused piece moves
			if(tile == this.moves[i]) { // if the the clicked tile matches a move of the focused piece
				// move the piece to the new tile
				movePiece(focus, tile);
				// Switch the team's turn
				if(turn == 'w') {
					turn = 'b';
				}
				else {
					turn = 'w';
				}
				// end the loop
				break;
			}
		}
		if(!pawnChange) { // remove focus unless pawn is being promoted
			focus = -1;
		}
	}

	/**
	 * Method to let user promote pawn
	 */
	public void promote(int piece) {
		// update the pawn image to the choices image
		pieceImgs[piece].setImage(getImage(logic.getPieces()[piece].getTeam() + "choices.png"));
		// adjust the image position
		pieceImgs[piece].setxPos(pieceImgs[piece].getxPos() - 80);
		pieceImgs[piece].setyPos(pieceImgs[piece].getyPos() - 5);
		// remove and add all other images to make them below the focus piece image
		for(int i = 0; i < 32; i++) {
			if(i != piece && logic.getPieces()[i].getTile() >= 0) {
				remove(pieceImgs[i]);
				add(pieceImgs[i]);
			}
		}
		// state that pawn is being promoted
		this.pawnChange = true;
	}

	/**
	 * Method to return the image in the source code
	 */
	public ImageIcon getImage(String filename) {
		try {
			return new ImageIcon(ImageIO.read(getClass().getResource(filename)));
		}
		catch (IOException e) {
			return new ImageIcon();
		}
	}

	/**
	 * @param args Self Testing
	 */
	public static void main(String[] args) {
		// declare and initialise chess ui with and without an ai
		Chess game = new Chess();
	}
}
