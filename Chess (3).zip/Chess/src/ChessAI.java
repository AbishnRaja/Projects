/**
 * 
 */

/**
 * @author Abishn
 * 
 * 
 * 
 * 
 * 
 * https://stackoverflow.com/questions/70116653/array-values-change-unexpectedly
 */
public class ChessAI extends Chess {

	final int DEPTH = 3;

	/**
	 * Default constructor
	 */
	public ChessAI() {
		// call the default constructor
		super();
	}

	/**
	 * This method calculates the best move the ai should make
	 * Minimax:
	 * Black:        6
	 *              / \
	 *             /   \
	 *           |/     \
	 * White:    6       8
	 *          /|\     /|\
	 *         / | \   / | \
	 * Black: 3  6  4 2  8  5
	 * 
	 * Minimax works by calculating the sum of values at a certain depth and determining what is the best move. If white 
	 * wants the highest possible value, and black wants the lowest possible value, then we know what would be the best 
	 * move to make using getLogic() method assuming that the opponent knows what moves they should make
	 * 
	 * Alpha-Beta pruning:
	 * Black:        6
	 *              / \
	 *             /   \
	 *           |/     \
	 * White:    6       8*
	 *          /|\     /|\
	 *         / | \   / | \
	 * Black: 3  6  4 2  8  X
	 * 
	 * Extending from minimax, white wants the highest number and black wants the lowest, when calculating the possibilities,
	 * we can say that the left branch has a smaller maximum value than the right, so the left branch is likely a better
	 * option than the right and no further calculation is required
	 * @return move
	 */


	private int[] getMove() {
		int out = 9999, tile = -1, index = -1, move;
		for (int i = 0; i < 16; i++) {
			Logic clone = cloneLogic(getLogic());
			clone.getPieces()[i].setHasMoved(true); // Moved outside the inner loop

			String[] moves = clone.getMoves(i);
			if (!"".equals(moves[0])) {
				for (int j = 0; j < moves.length; j++) {
					clone.getPieces()[i].setTile(Integer.parseInt(moves[j]));
					boolean isBlackUnderAttack = isUnderAttack(clone, 'b');

					if (isBlackUnderAttack) {
						// Defend the black piece being attacked
						movePiece(i, Integer.parseInt(moves[j]));
						return new int[]{i, Integer.parseInt(moves[j])};
					}

					// Check for capturing hanging pieces
					int targetTile = Integer.parseInt(moves[j]);
					if (shouldCaptureHangingPiece(clone, i, targetTile)) {
						movePiece(i, targetTile);
						return new int[]{i, targetTile};
					}

					move = alphabeta(clone, -9999, 9999, 'b', 0);
					if (move < out) {
						out = move;
						index = i;
						tile = targetTile;
					} else if (move == out) {
						// If the move has the same evaluation, consider defending, moving, or attacking more valuable pieces
						if (shouldDefend(clone, i, targetTile)) {
							index = i;
							tile = targetTile;
						} else if (shouldMove(clone, i, targetTile)) {
							index = i;
							tile = targetTile;
						} else if (shouldAttackMoreValuable(clone, i, targetTile)) {
							index = i;
							tile = targetTile;
						}
					}
				}
			}
		}
		return new int[]{index, tile};
	}

	private boolean shouldCaptureHangingPiece(Logic logic, int pieceIndex, int targetTile) {
		Piece[] pieces = logic.getPieces();
		Piece piece = pieces[pieceIndex];

		// Only consider capturing if the piece is black
		if (piece != null && piece.getTeam() == 'b') {
			Piece targetPiece = pieces[pieceIndex];
			if (targetPiece != null && targetPiece.getTeam() == 'w') {
				int pieceValue = getPieceValue(piece);
				int targetPieceValue = getPieceValue(targetPiece);

				// Capture the hanging white piece if its value is less than or equal to the black piece's value,
				// or if the target piece is a pawn
				if (targetPieceValue <= pieceValue) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Check if the black piece at pieceIndex should be defended against an attack on targetTile
	 * @param logic the current game state
	 * @param pieceIndex the index of the black piece
	 * @param targetTile the tile being attacked
	 * @return true if the piece should be defended, false otherwise
	 */
	private boolean shouldDefend(Logic logic, int pieceIndex, int targetTile) {
		Piece piece = logic.getPieces()[pieceIndex];

		// Only consider defending if the piece is black and the target piece is white
		if (piece.getTeam() == 'b' && targetTile != -1 && piece.getTeam() == 'w') {
			int pieceValue = getPieceValue(piece);
			int targetPieceValue = getPieceValue(piece);

			// Defend the piece if the target piece value is greater or equal
			return targetPieceValue >= pieceValue;
		} else {
			return false;
		}
	}

	/**
	 * Check if the black piece at pieceIndex should move to targetTile
	 * @param logic the current game state
	 * @param pieceIndex the index of the black piece
	 * @param targetTile the tile to move to
	 * @return true if the piece should move, false otherwise
	 */
	private boolean shouldMove(Logic logic, int pieceIndex, int targetTile) {
		if(pieceIndex <= 31 && pieceIndex >= 0) {
			Piece piece = logic.getPieces()[pieceIndex];
			Piece targetPiece = logic.getPieces()[logic.pieceAtTile(targetTile)];

			if (targetTile <= 63 && targetTile >= 0) {
				// Only consider moving if the piece is black and the target tile is empty or has a white piece
				if (piece.getTeam() == 'b' && (targetPiece == null || targetPiece.getTeam() == 'w')) {
					int pieceValue = getPieceValue(piece);

					// Move the piece if the target piece is null or has a lower value
					if (targetPiece == null) {
						return true;
					} else {
						int targetPieceValue = getPieceValue(targetPiece);
						return targetPieceValue < pieceValue;
					}
				}
				else {
					return false;
				}
			}
		}
		return false;
	}

	/**
	 * Check if the black piece at pieceIndex should attack a more valuable piece at targetTile
	 * @param logic the current game state
	 * @param pieceIndex the index of the black piece
	 * @param targetTile the tile with the piece to attack
	 * @return true if the piece should attack a more valuable piece, false otherwise
	 */
	private boolean shouldAttackMoreValuable(Logic logic, int pieceIndex, int targetTile) {
		Piece piece = logic.getPieces()[pieceIndex];
		Piece targetPiece = logic.getPieces()[logic.pieceAtTile(targetTile)];

		// Only consider attacking if the piece is black and the target piece is not null and has a higher value
		if (piece.getTeam() == 'b' && targetPiece != null) {
			int pieceValue = getPieceValue(piece);
			int targetPieceValue = getPieceValue(targetPiece);

			// Attack the piece if the target piece value is greater
			return targetPieceValue > pieceValue;
		} else {
			return false;
		}
	}

	/**
	 * Check if a piece of the specified team is under attack in the current game state
	 * @param logic the current game state
	 * @param team the team to check for (either 'w' or 'b')
	 * @return true if a piece of the specified team is under attack, false otherwise
	 */
	public boolean isUnderAttack(Logic logic, char team) {
		for (int i = 0; i < 16; i++) {
			Piece currentPiece = logic.getPieces()[i];
			if (currentPiece.getTeam() == team) {
				continue;
			}

			String[] moves = logic.getMoves(i);
			for (int k = 0; k < moves.length; k++) {
				if (Integer.parseInt(moves[k]) == logic.getPieces()[i].getTile()) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * This method creates an optimised search tree of the possible moves the ai can make
	 * 
	 * @param logic
	 * @param piece
	 * @param moves
	 * @param next
	 * @param turn
	 * @return
	 */
	private int alphabeta(Logic lastLogic, int a, int b, char turn, int depth) {
		if (depth >= DEPTH) {
			return evaluateBoard(lastLogic);
		}
		int offset = 0, value, lastValue = b;
		boolean max = false;
		if (turn == 'w') {
			offset = 16;
			max = true;
			lastValue = a;
		}
		value = lastValue;
		for (int i = 0; i < 16; i++) {
			int index = i + offset;
			String[] moves = lastLogic.getMoves(index);

			for (int j = 0; j < moves.length; j++) {
				if (moves[0] == "") {
					continue;
				}
				Logic clone = cloneLogic(lastLogic);
				clone.getPieces()[i].setHasMoved(true);
				clone.getPieces()[i].setTile(Integer.parseInt(moves[j]));
				isUnderAttack(clone, 'b');
				int newValue = alphabeta(clone, a, b, 'b', depth + 1);
				if (max && newValue > value) {
					value = newValue;
					if (value > a) {
						a = value;
					}
				} else if (!max && newValue < value) {
					value = newValue;
					if (value < b) {
						b = value;
					}
				}
				if (a >= b) {
					break;
				}
			}
		}
		return value;
	}

	private int evaluateBoard(Logic logic) {

		int score = 0;
		for(int i = 0; i < 32; i++) {
			score += getPieceValue(logic.getPieces()[i]);
		}
		return score;
	}

	/**
	 * 
	 * @param piece
	 * @param tile
	 * @return
	 */
	private int getPieceValue(Piece piece) {
		if(piece.getTile() < 0)
			return 0;
		boolean reverse = false;
		if(piece.getTeam() == 'b') {
			reverse = true;
		}
		// create a table of multipliers for rewarding Piece Placement
		final int[] PAWN = {
				00,00,00,00,00,00,00,00,
				05,05,05,05,05,05,05,05,
				02,02,03,04,04,03,02,02,
				01,01,02,03,03,02,01,01,
				00,00,00,02,02,00,00,00,
				01,-1,-1,00,00,-1,-1,01,
				01,02,02,-2,-2,02,02,01,
				00,00,00,00,00,00,00,00},
				KNIGHT = {
						-5,-4,-3,-3,-3,-3,-4,-5,
						-4,-3,00,00,00,00,-3,-4,
						-3,00,01,02,02,01,00,-3,
						-3,01,02,03,03,02,01,-3,
						-3,01,02,03,03,02,01,-3,
						-3,00,01,02,02,01,00,-3,
						-4,-3,00,00,00,00,-3,-4,
						-5,-4,-3,-3,-3,-3,-4,-5},
				BISHOP = {
						-2,-1,-1,-1,-1,-1,-1,-2,
						-1,00,00,00,00,00,00,-1,
						-1,00,01,02,02,01,00,-1,
						-1,01,01,02,02,01,01,-1,
						-1,00,02,02,02,02,00,-1,
						-1,01,01,01,01,01,01,-1,
						-1,00,00,00,00,00,00,-1,
						-2,-1,-1,-1,-1,-1,-1,-2},
				ROOK = {
						00,00,00,00,00,00,00,00,
						01,02,02,02,02,02,02,01,
						01,00,00,00,00,00,00,01,
						01,00,00,00,00,00,00,01,
						01,00,00,00,00,00,00,01,
						01,00,00,00,00,00,00,01,
						01,00,00,00,00,00,00,01,
						00,00,00,01,01,00,00,00},
				QUEEN = {
						-2,-1,-1,-1,-1,-1,-1,-2,
						-1,00,00,00,00,00,00,-1,
						-1,00,01,01,01,01,00,-1,
						-1,00,01,01,01,01,00,-1,
						-1,00,01,01,01,01,00,-1,
						-1,01,01,01,01,01,01,-1,
						-1,00,01,00,00,00,00,-1,
						-2,-1,-1,-1,-1,-1,-1,-2},
				KING = {
						-3,-4,-4,-5,-5,-4,-4,-3,
						-3,-4,-4,-5,-5,-4,-4,-3,
						-3,-4,-4,-5,-5,-4,-4,-3,
						-3,-4,-4,-5,-5,-4,-4,-3,
						-2,-3,-3,-4,-4,-3,-3,-2,
						-1,-2,-2,-2,-2,-2,-2,-1,
						02,02,00,00,00,00,02,02,
						02,03,01,00,00,01,03,02};

		// get a multiplier for the piece depending on the team
		int multiplier;
		if(piece.getTeam() == 'w') {
			multiplier = 1;
		}
		else
			multiplier = -1;

		switch (piece.getType()) {
		case "pawn":
			if(reverse)
				return 1 * multiplier + reverse(PAWN)[piece.getTile()];
			return 1 * multiplier + PAWN[piece.getTile()];
		case "knight":
			if(reverse)
				return 3 * multiplier + reverse(KNIGHT)[piece.getTile()];
			return 3 * multiplier + KNIGHT[piece.getTile()];
		case "bishop":
			if(reverse)
				return 3 * multiplier + reverse(BISHOP)[piece.getTile()];
			return 3 * multiplier + BISHOP[piece.getTile()];
		case "rook":
			if(reverse)
				return 5 * multiplier + reverse(ROOK)[piece.getTile()];
			return 5 * multiplier + ROOK[piece.getTile()];
		case "queen":
			if(reverse)
				return 9 * multiplier + reverse(QUEEN)[piece.getTile()];
			return 9 * multiplier + QUEEN[piece.getTile()];
		case "king":
			if(reverse)
				return 9999 * multiplier + reverse(KING)[piece.getTile()];
			return 9999 * multiplier + KING[piece.getTile()];
		default:
			return 0;
		}

	}

	/**
	 * Method to reverse an array
	 */
	public int[] reverse(int[] array) {
		// declare array of equal length to input
		int[] out = new int[array.length];
		// add data in reverse to the array
		for(int i = 0; i < out.length; i++) {
			out[i] = array[array.length - 1 - i];
		}
		// return the reversed array
		return out;
	}

	@Override
	/**
	 * Method to check if the selected tile is a valid move
	 */
	public void checkValid(int tile) {
		for(int i = 0; i < getMoves().length; i++) { // check all of the focused piece moves
			if(tile == getMoves()[i]) { // if the the clicked tile matches a move of the focused piece
				// move the piece to the new tile
				movePiece(getFocus(), tile);
				// calculate ai move and move piece
				int aiMove[] = getMove();
				movePiece(aiMove[0], aiMove[1]);
				// end the loop
				break;
			}
		}
		if(!isPawnChange()) { // remove focus unless pawn is being promoted
			setFocus(-1);
		}
	}

	/**
	 * @param args Self Testing
	 */
	public static void main(String[] args) {
		ChessAI ai = new ChessAI();
	}

	/**
	 * Method to clone logic object
	 */
	public Logic cloneLogic(Logic logic) {
		Logic out = new Logic();
		Piece[] pieces = new Piece[32];
		for(int i = 0; i < pieces.length; i++) {
			pieces[i] = new Piece(logic.getPieces()[i].getType(), logic.getPieces()[i].getTeam(), logic.getPieces()[i].getTile());
		}
		out.setPieces(pieces);
		return out;
	}
}
