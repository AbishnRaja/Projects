import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 * 
 */

/**
 * @author Alvin
 * Date: June 2023
 * Description: This class accesses and modifies files
 * Method List:
 * + String loadFile() throws IOException | Method to return the contents of a file as a string
 * + void print() | method to display the file contents to a window
 * + void saveFile(String contents) throws IOException | method to save contents to the file
 * + String getFilename()
 * + void setFilename(String filename)
 * static void main(String[] args) | self testing
 */
public class FileAccess {
	// Private attributes
	String filename;

	/**
	 * Default constructor
	 */
	public FileAccess() {
		// initialise attributes
		filename = "";
	}
	/**
	 * Overloaded constructor
	 */
	public FileAccess(String filename) {
		// initialise attributes
		this.filename = filename;
	}
	/**
	 * Method to read file contents string
	 */
	public String loadFile() throws IOException {
		// declare a variable to read a file
		// declare a variable to read the lines of the file
		BufferedReader input = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream(filename)));
		// declare and initialise an empty string for the file contents
		String file = "";
		String line = input.readLine();
		if(line != null ) {
			// add line if not null
			file += line;
			// loop indefinitely
			while(true){
				// check if the next line is null
				line = input.readLine();
				if(line != null ) { // if not null
					// move to the next line of the output
					file += "\n";
					// add line
					file += line;
				}
				else {
					// end loop if null
					break;
				}
			}
		}
		// close the file
		input.close();
		// return the string
		return file;
	}
	/**
	 * This method shows the file as a window
	 */
	public void print() {
		try { // error trapping
			new PrintFile(loadFile());
		}
		catch (Exception e) {}
	}
	/**
	 * Method write contents to a file
	 * @return 
	 */
	public void saveFile(String contents) throws IOException {
		// create a file with the filename
		File file = new File(filename);
		// declare and initialise the variable to write to the file
		FileWriter fw = new FileWriter(file);
		// add contents then close the file
		fw.write(contents);
		fw.close();
	}
	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}
	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}
	/**
	 * @param args Self Testing
	 */
	public static void main(String[] args) {
		// initialise new object
		FileAccess file = new FileAccess();
		// Gets All The Attributes
		file.setFilename("Output.txt");

		// Saves The File
		try {
			file.saveFile("Testing");
		} catch (IOException e) {
			// Display Error Message
			JOptionPane.showMessageDialog(null, "File Has Corrupted!!");
		}

		// Loads The File
		try {
			JOptionPane.showMessageDialog(null, file.loadFile());
		} catch (IOException e) {
			// Error Message 
			JOptionPane.showMessageDialog(null, "Error In Loading The File");
		}

		// Sets All The Attributes
		file.getFilename();
	}
}

