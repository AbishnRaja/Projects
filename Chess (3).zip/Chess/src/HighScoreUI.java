import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

/**
 * 
 */

/**
 * @author Abishn
 * Date: June 2023
 * Description: This method interfaces with the user the old games
 * Method List: 
 * + void actionPerformed | gets called when an action event occurs
 * + static void main | Self testing
 * Sources:
 * 
 *
 */
public class HighScoreUI extends JFrame implements ActionListener{

	/**
	 * Private Instance Variables
	 */
	private HighScores data;
	private JComboBox tiles[], sort;
	private JLabel lblWinner, lblDate;
	private JTextArea date, winner;
	private JButton btnSort, btnSearch, btnPrint, btnDelete;
	private FileAccess file;
	private final String[] PIECES = {"-1","0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17",
			"18","19","20","21","22","23","24","25","26","27","28","29","30","31"},
			CHOICES = {"Date", "Winner", "Game"};

	/**
	 * Default constructor
	 */
	public HighScoreUI() {
		// call parent constructor
		super();
		// set the window dimensions and layout style
		setSize(600,300);
		setLayout(null);
		// initialise attributes
		data = new HighScores("highscores.txt");
		tiles = new JComboBox[64];
		// initialise and set the placement of every box
		for(int i = 0; i < 8; i++) {
			for(int j = 0; j < 8; j++) {
				int index = i * 8 + j;
				tiles[index] = new JComboBox(PIECES);
				// disable the box
				tiles[index].setEnabled(false);
				tiles[index].setBounds(j*50+10, i*25+10, 40, 25);
				// add the box
				add(tiles[index]);
			}
		}
		// initialise and set evey label
		lblDate = new JLabel("Date:");
		lblDate.setBounds(420, 45, 60, 25);
		add(lblDate);

		lblWinner = new JLabel("Winner:");
		lblWinner.setBounds(420, 70, 60, 25);
		// disable this label
		lblWinner.setEnabled(false);
		add(lblWinner);

		// add the box for sort/search method
		sort = new JComboBox(CHOICES);
		sort.setBounds(420, 10, 80, 25);
		add(sort);
		sort.addActionListener(this);
		// initialise and add all inputs
		date = new JTextArea();
		date.setSize(80, 25);
		date.setLocation(480, 45);
		date.setText("yyyy/mm/dd");
		add(date);
		winner = new JTextArea();
		winner.setSize(80, 25);
		winner.setLocation(480, 80);
		add(winner);
		// initialise and add all buttons
		btnSort = new JButton("Sort");
		btnSort.setBounds(420, 115, 100, 25);
		add(btnSort);
		btnSort.addActionListener(this);
		btnSearch = new JButton("Search");
		btnSearch.setBounds(420, 150, 100, 25);
		add(btnSearch);
		btnSearch.addActionListener(this);
		btnPrint = new JButton("Print");
		btnPrint.setBounds(420, 185, 100, 25);
		add(btnPrint);
		btnPrint.addActionListener(this);
		btnDelete = new JButton("Delete");
		btnDelete.setBounds(420, 220, 100, 25);
		// disable the delete button
		btnDelete.setEnabled(false);
		add(btnDelete);
		btnDelete.addActionListener(this);

		// Show frame, make it not resizable, and have it end the program when x is pressed
		setVisible(true);
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	/**
	 * Action event
	 */
	public void actionPerformed (ActionEvent e){
		if(e.getSource() == sort) { // if the sorting method change
			int sortMethod = sort.getSelectedIndex();
			switch(sortMethod) { // set the sorting method
			case 0: { // date
				// enable date input and disable the rest
				for(int i = 0; i < 64; i++) {
					tiles[i].setEnabled(false);
				}
				date.setEnabled(true);
				winner.setEnabled(false);
				lblDate.setEnabled(true);
				lblWinner.setEnabled(false);
				btnDelete.setEnabled(false);
				break;
			}
			case 1:{ // winner
				// enable winner input and disable the rest
				for(int i = 0; i < 64; i++) {
					tiles[i].setEnabled(false);
				}
				date.setEnabled(false);
				winner.setEnabled(true);
				lblDate.setEnabled(false);
				lblWinner.setEnabled(true);
				btnDelete.setEnabled(false);
				break;
			}
			default:{ // board
				// enable all inputs
				for(int i = 0; i < 64; i++) {
					tiles[i].setEnabled(true);
				}
				date.setEnabled(true);
				winner.setEnabled(true);
				lblDate.setEnabled(true);
				lblWinner.setEnabled(true);
				btnDelete.setEnabled(true);
			}
			}
		}
		else if(e.getSource() == btnSort) {
			// get the sorting method
			data.shellSort(sort.getSelectedItem().toString());
		}
		else if(e.getSource() == btnSearch) {
			// get the searching method and the inputed data
			int method = sort.getSelectedIndex();
			switch(method) {
			case 1:{ // by winner
				int index = data.jumpWinnerSearch(winner.getText());
				if(index >= 0) { // display found message
					JOptionPane.showMessageDialog(null, "Found at game " + (index + 1));
				}
				else { // display not found message
					JOptionPane.showMessageDialog(null, "Winner not found!");
				}
				break;
			}
			case 2:{ // by board
				String date = this.date.getText();
				String winner = this.winner.getText();
				int board[] = new int[32];
				for(int i = 0; i < tiles.length; i++) {
					if(tiles[i].getSelectedIndex() > 0) {
						int index = tiles[i].getSelectedIndex() - 1;
						board[index] = i;
					}
				}
				Logic recordToSearch = new Logic(date, board, winner);
				int index = data.jumpSearch(recordToSearch);
				if(index >= 0) { // display found message
					JOptionPane.showMessageDialog(null, "Found at game " + (index + 1));
				}
				else { // display not found message
					JOptionPane.showMessageDialog(null, "Game not found!");
				}
				break;
			}
			default:{ // by date
				// look for index
				int index = data.jumpDateSearch(date.getText());
				if(index >= 0) { // display found message
					JOptionPane.showMessageDialog(null, "Found at game " + (index + 1));
				}
				else { // display not found message
					JOptionPane.showMessageDialog(null, "Date not found!");
				}
			}
			}
		}
		else if(e.getSource() == btnPrint) {
			// show file contents
			data.print();
		}
		else if(e.getSource() == btnDelete) {
			// get all contents from the ui
			String date = this.date.getText();
			String winner = this.winner.getText();
			int board[] = new int[32];
			for(int i = 0; i < tiles.length; i++) {
				if(tiles[i].getSelectedIndex() > 0) {
					int index = tiles[i].getSelectedIndex() - 1;
					board[index] = i;
				}
			}
			// declare initialise logic variable
			Logic recordToSearch = new Logic(date, board, winner);
			// delete the game from the list
			if(data.delete(recordToSearch)) { // save file and display deleted message
				data.saveToFile();
				JOptionPane.showMessageDialog(null, "Game deleted");
			}
			else { // display not deleted message
				JOptionPane.showMessageDialog(null, "Game not found!");
			}
		}
	}

	/**
	 * Self testing main
	 * @param args
	 */
	public static void main(String[] args) {
		new HighScoreUI();
	}
}
