import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

/**
 * 
 */

/**
 * @author Abishn
 * 
 * Sources:
 * 			https://www.geeksforgeeks.org/shellsort - ShellSort is a sorting algorithm that gradually reduces the gap between 
 * 												elements and sorts them in a series of passes. It has a better time 
 * 												complexity than Insertion Sort for larger arrays.
 * 
 * 			https://www.educative.io/answers/what-is-a-jump-search - It reduces the number of comparisons compared to linear search 
 * 															and is useful for large arrays, provided they are sorted beforehand. 
 * 																	 
 *
 */
public class HighScores {

	// Private Attributes
	private Logic game[];
	private int maxSize, size;
	private FileAccess file;
	private PrintFile display;

	/**
	 * @param args
	 */

	/**
	 * Default Constructor
	 */
	public HighScores() {
		// initialise attributes
		this.maxSize = 10;
		this.size = 0;
		this.game = new Logic[maxSize];
		this.file = new FileAccess("");
	}

	/**
	 * Overloaded Constructor
	 * @param filename
	 */
	public HighScores(String filename) {
		// initialise attributes
		this.file = new FileAccess(filename);
		// get the file content
		String contents = "";
		try {
			contents = this.file.loadFile();
		} catch (Exception e) {}
		// get each line of the file
		String[] contentsArray = contents.split("\n");
		// initialise the size
		size = (contentsArray.length-1)/10;
		maxSize = size + 10;
		// add the data to the logics attributes
		this.game = new Logic[maxSize];
		for(int i = 0; i < size; i++) {
			// declare an integer array of length 32
			int[] board = new int[32];
			// for every row, split to the individual number
			for(int j = 0; j < 8; j++) {
				String[] boardRow = contentsArray[i * 11 + j + 2].split(",");
				// check every element for each row
				for(int k = 0; k < 8; k++) {
					// get the integer value of the piece
					int piece = Integer.parseInt(boardRow[k]);
					// add the tile to the board if the number is valid
					if(piece > -1 && piece < 32)
						board[piece] = j * 8 + k;
				}
			}
			// initialise logic attribute with data
			game[i] = new Logic(contentsArray[i * 11], board, contentsArray[i * 11 + 1]);
		}
	}

	public boolean insert(Logic game) {
		// If The Size Is Under The Maximum Size
		if (size < maxSize) {
			size++; // Size = Size + 1
			this.game[size-1] = game; // Initializes The Size with Record
			return true; // Return That Insert Was Successful
		}

		return false; // Return That Insert Failed
	}

	/**
	 * Checks If Two Records are Completely Identical To Another
	 */
	public boolean areSameRecord(Logic test, Logic test1) {
		if (test.getDate().equals(test1.getDate()) 
				&& test.getWinner().equals(test1.getWinner()) && test.toString().equals(test1.toString())) {
			return true;
		}
		return false; 
	}


	// Shell Sort
	public void shellSort(String sortType) {
		int n = size;
		switch(sortType.toLowerCase()) {
		case "date":{
			// Start with a large gap and reduce it
			for (int gap = n / 2; gap > 0; gap /= 2) {

				// Perform insertion sort on elements separated by the gap
				for (int i = gap; i < n; i += 1) {
					Logic temp = game[i];
					int j;

					// Shift elements to the right within the gap until the correct position is found
					for (j = i; j >= gap && game[j - gap].getDate().compareToIgnoreCase(temp.getDate()) < 0; j -= gap) {
						game[j] = game[j - gap];
					}

					// Place the current elements in their correct position
					game[j] = temp;
				}
			}
			break;
		}
		case "winner":{
			// Start with a large gap and reduce it
			for (int gap = n / 2; gap > 0; gap /= 2) {

				// Perform insertion sort on elements separated by the gap
				for (int i = gap; i < n; i++) {
					Logic temp = game[i];
					int j;

					// Shift elements to the right within the gap until the correct position is found
					for (j = i; j >= gap && game[j - gap].getWinner().compareToIgnoreCase(temp.getWinner()) > 0; j -= gap) {
						game[j] = game[j - gap];
					}

					// Place the current elements in their correct position
					game[j] = temp;
				}
			}
			break;
		}
		default:{
			// Start with a large gap and reduce it
			for (int gap = n / 2; gap > 0; gap /= 2) {

				// Perform insertion sort on elements separated by the gap
				for (int i = gap; i < n; i += 1) {
					Logic temp = game[i];
					int j;

					// Shift elements to the right within the gap until the correct position is found
					for (j = i; j >= gap && (game[j - gap].getDate() + game[j - gap].getWinner() + game[j - gap].toString()).compareTo(temp.getDate() + temp.getWinner() + temp.toString()) < 0; j -= gap) {
						game[j] = game[j - gap];
					}

					// Place the current elements in their correct position
					game[j] = temp;
				}
			}
		}
		}
	}

	/**
	 * Swap Method
	 * @param i
	 * @param j
	 */
	public void swap(int i, int j) {
		Logic temp = game[i];
		game[i] = game[j];
		game[j] = temp;
	}

	public boolean change(Logic oldR, Logic newR) {
		// For Loop To Look Through Every Initialized Element
		for (int i = 0; i < size; i++) {
			// Check If They are The Same Through Method
			if (areSameRecord(game[i], oldR)) {
				// Overwrite Chosen Record With New List
				game[i] = newR;

				// Sort The List by piece placement
				shellSort("game");

				// Returns When Change Successful
				return true;
			}
		}
		return false;
	}

	/*
	 * saveToFile Method
	 */
	public void saveToFile() {
		String out = "";
		for (int i = 0; i < size; i++) {
			out += game[i].getDate() + "\n" + game[i].getWinner() + "\n" + game[i].toString() + "\n";
		}
		try {
			file.saveFile(out);
		} catch (Exception e) {}
	}

	public boolean changeMaxSize(int newSize) {

		// If The new Size Requested is Larger Or Equal Than The Size Filled
		if (newSize >= size) {

			// Creates a New Record Array
			Logic tempList[] = new Logic[newSize];

			// For Loop To Go Through Each Element
			for (int i = 0; i < size; i++) {

				tempList[i] = game[i];
			}

			// Make The Attribute Equal To The New List
			this.game = tempList;

			// Update Max Size Attribute
			this.maxSize = newSize;

			return true;
		}

		return false;
	}

	public int compare(Logic v1, Logic v2) {
		int result = v1.getDate().compareToIgnoreCase(v2.getDate());
		if (result != 0) {
			return result;
		}
		return (v1.getWinner().compareToIgnoreCase(v2.getWinner()));
	}

	/**
	 * @return the game
	 */
	public Logic[] getGame() {
		return game;
	}

	/**
	 * @param game the game to set
	 */
	public void setGame(Logic[] game) {
		this.game = game;
	}

	/**
	 * @return the maxSize
	 */
	public int getMaxSize() {
		return maxSize;
	}

	/**
	 * @param maxSize the maxSize to set
	 */
	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}

	/**
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}

	/**
	 * Delete Method, Uses the JumpSearch Method To Search The Whole List
	 */
	public boolean delete(Logic record) {
		int index = -1;

		// Find the index of the record to delete
		for (int i = 0; i < size; i++) {
			if (game[i].toString().equals(record.toString()) && game[i].getDate().equals(record.getDate()) && game[i].getWinner().equals(record.getWinner())) {
				index = i;
				break;
			}
		}

		// If the record was found, delete it
		if (index != -1) {
			// Shift elements to the left to fill the gap
			game[index] = game[size - 1];

			size--; // Reduce the size of the array

			// Sort the array again
			shellSort("game");

			return true; // Return that deletion was successful
		}

		return false; // Return that deletion failed
	}


	public int jumpSearch(Logic target) {
		// sort data by game
		shellSort("game");
		int n = size;
		int step = (int) Math.floor(Math.sqrt(n)); // Determine The Step Size
		int prev = 0; // Initialize The Previous Index
		int index = -1;

		// Find The Block Where The Target Element May Exist
		while(prev < n) {
			if((game[prev].getDate() + game[prev].getWinner() + game[prev].toString()).compareTo(target.getDate() + target.getWinner() + target.toString()) < 0) {
				break;
			}
			else if((game[prev].getDate() + game[prev].getWinner() + game[prev].toString()).compareTo(target.getDate() + target.getWinner() + target.toString()) == 0){
				return prev;
			}
			System.out.println(prev);
			prev += step;
		}
		if(index < 0) {
			if(prev >= n)
				prev = n - 1;
			while(prev >= 0) {
				if((game[prev].getDate() + game[prev].getWinner() + game[prev].toString()).compareTo(target.getDate() + target.getWinner() + target.toString()) > 0) {
					break;
				}
				else if((game[prev].getDate() + game[prev].getWinner() + game[prev].toString()).compareTo(target.getDate() + target.getWinner() + target.toString()) == 0){
					return prev;
				}
				prev--;
			}
		}
		return -1;
	}

	public int jumpDateSearch(String date) {
		// sort data by date
		shellSort("date");
		int n = size;
		int step = (int) Math.floor(Math.sqrt(n)); // Determine The Step Size
		int prev = 0; // Initialize The Previous Index
		int index = -1;
		// Find The Block Where The Target Element May Exist
		while(prev < n) {
			if(game[prev].getDate().compareToIgnoreCase(date) < 0) {
				break;
			}
			else if(game[prev].getDate().compareToIgnoreCase(date) == 0){
				return prev;
			}
			prev += step;
		}
		if(index < 0) {
			if(prev >= n)
				prev = n - 1;
			while(prev >= 0) {
				if(game[prev].getDate().compareToIgnoreCase(date) > 0) {
					break;
				}
				else if(game[prev].getDate().compareToIgnoreCase(date) == 0){
					return prev;
				}
				prev--;
			}
		}
		return -1;
	}

	public int jumpWinnerSearch(String target) {
		// sort data by winner
		shellSort("winner");
		int n = size;
		int step = (int) Math.floor(Math.sqrt(n)); // Determine The Step Size
		int prev = 0; // Initialize The Previous Index
		int index = -1;

		// Find The Block Where The Target Element May Exist
		while(prev < n) {
			if(game[prev].getWinner().compareToIgnoreCase(target) > 0) {
				break;
			}
			else if(game[prev].getWinner().compareToIgnoreCase(target) == 0){
				return prev;
			}
			prev += step;
		}
		if(index < 0) {
			if(prev >= n)
				prev = n - 1;
			while(prev >= 0) {
				if(game[prev].getWinner().compareToIgnoreCase(target) < 0) {
					break;
				}
				else if(game[prev].getWinner().compareToIgnoreCase(target) == 0){
					return prev;
				}
				prev--;
			}
		}
		return -1;
	}

	public void print() {
		String out = "";
		for(int i = 0; i < size; i++){
			out += game[i].getDate() + "\n";
			out += game[i].getWinner() + "\n";
			out += game[i].toString() + "\n";
		}
		display = new PrintFile(out);
	}

	public static void main(String[] args) {

		HighScores highScores = new HighScores("highscores.txt");

		while (true) {
			char command = JOptionPane.showInputDialog(null,
					"'i/I' to Insert\n'd' to Delete\n'c/C' to Change\n'p/P' to Print\n'm/M' to Change Max Size\n"
							+ "'j/J' to Jump Search\n's/S' To Save To a File\n\nCurrent Max Size: " + highScores.getMaxSize()
							+ "\nCurrent Size Filled: " + highScores.getSize(),
					"i").charAt(0);

			switch (command) {
			case 'i':
			case 'I': {
				String date = JOptionPane.showInputDialog(null, "Enter Date (yyyy/mm/dd):");
				String oldboardStr[] = JOptionPane.showInputDialog(null, "Enter pieces' tiles in order to Search\n0,1,2,3...29,30,31:",
						"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63").split(",");
				int board[] = new int[oldboardStr.length];
				for(int i = 0; i < board.length; i++) {
					board[i] = Integer.parseInt(oldboardStr[i]);
				}
				String winner = JOptionPane.showInputDialog(null, "Enter Winner:");

				Logic newRecord = new Logic(date, board, winner);

				if (highScores.insert(newRecord)) {
					JOptionPane.showMessageDialog(null, "Insert Successful.");
				} else {
					JOptionPane.showMessageDialog(null, "Insert Failed.");
				}

				break;
			}

			case 'd':
			case 'D': {
				String date = JOptionPane.showInputDialog(null, "Enter Date (yyyy/mm/dd):");
				String oldboardStr[] = JOptionPane.showInputDialog(null, "Enter pieces' tiles in order to Search\n0,1,2,3...29,30,31:",
						"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63").split(",");
				int board[] = new int[oldboardStr.length];
				for(int i = 0; i < board.length; i++) {
					board[i] = Integer.parseInt(oldboardStr[i]);
				}
				String winner = JOptionPane.showInputDialog(null, "Enter Winner:");

				Logic recordToDelete = new Logic(date, board, winner);

				if (highScores.delete(recordToDelete)) {
					JOptionPane.showMessageDialog(null, "Deletion Successful.");
				} else {
					JOptionPane.showMessageDialog(null, "Deletion Failed.");
				}

				break;
			}

			case 'c':
			case 'C': {
				String oldDate = JOptionPane.showInputDialog(null, "Enter OLD Date (yyyy/mm/dd):");
				String oldWinner = JOptionPane.showInputDialog(null, "Enter OLD Winner:");

				String newDate = JOptionPane.showInputDialog(null, "Enter NEW Date (yyyy/mm/dd):");
				String newWinner = JOptionPane.showInputDialog(null, "Enter NEW Winner:");

				String oldboardStr[] = JOptionPane.showInputDialog(null, "Enter pieces' tiles in order to Search\n0,1,2,3...29,30,31:",
						"1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63").split(",");
				int oldboard[] = new int[oldboardStr.length];
				for(int i = 0; i < oldboard.length; i++) {
					oldboard[i] = Integer.parseInt(oldboardStr[i]);
				}

				String newboardStr[] = JOptionPane.showInputDialog(null, "Enter pieces' tiles in order to Search\n0,1,2,3...29,30,31:",
						"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63").split(",");
				int newboard[] = new int[newboardStr.length];
				for(int i = 0; i < newboard.length; i++) {
					newboard[i] = Integer.parseInt(newboardStr[i]);
				}

				Logic oldRecord = new Logic(oldDate, oldboard, oldWinner);
				Logic newRecord = new Logic(newDate, newboard, newWinner);

				if (highScores.change(oldRecord, newRecord)) {
					JOptionPane.showMessageDialog(null, "Change Successful.");
				} else {
					JOptionPane.showMessageDialog(null, "Change Failed.");
				}
				break;
			}

			case 'p':
			case 'P': {
				highScores.print();
				break;
			}

			case 'm':
			case 'M': {
				int newMaxSize = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter New Max Size:"));

				if (highScores.changeMaxSize(newMaxSize)) {
					JOptionPane.showMessageDialog(null, "Size Change Successful.");
				} else {
					JOptionPane.showMessageDialog(null, "Size Change Failed.");
				}
				break;
			}

			case 'j':
			case 'J': {
				command = JOptionPane.showInputDialog(null,
						"'d/D' to search date\n'w/W' to search winner\nSearch by board layout by default",
						"d").charAt(0);

				switch (command) {
				case 'd', 'D':{
					String date = JOptionPane.showInputDialog(null, "Enter Date to Search (yyyy/mm/dd):");
					int searchResult = -1;
					try {
						searchResult = highScores.jumpDateSearch(date) + 1;
					} catch (Exception e) {}

					if (searchResult > 0) {
						JOptionPane.showMessageDialog(null, "Record found at position: " + searchResult);
					} else {
						JOptionPane.showMessageDialog(null, "Record not found.");
					}
					break;
				}
				case 'w', 'W':{
					String winner = JOptionPane.showInputDialog(null, "Enter Winner to Search:");
					int searchResult = -1;
					try {
						searchResult = highScores.jumpWinnerSearch(winner) + 1;
					} catch (Exception e) {}

					if (searchResult > 0) {
						JOptionPane.showMessageDialog(null, "Record found at position: " + searchResult);
					} else {
						JOptionPane.showMessageDialog(null, "Record not found.");
					}
					break;
				}
				default:{
					String date = JOptionPane.showInputDialog(null, "Enter Date to Search (yyyy/mm/dd):");
					String boardStr[] = JOptionPane.showInputDialog(null, "Enter pieces' tiles in order to Search\n0,1,2,3...29,30,31:",
							"0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63").split(",");
					String winner = JOptionPane.showInputDialog(null, "Enter Winner to Search:");
					int board[] = new int[boardStr.length];
					for(int i = 0; i < board.length; i++) {
						board[i] = Integer.parseInt(boardStr[i]);
					}
					Logic recordToSearch = new Logic(date, board, winner);

					int searchResult = -1;
					try {
						searchResult = highScores.jumpSearch(recordToSearch) + 1;
					} catch (Exception e) {}

					if (searchResult > 0) {
						JOptionPane.showMessageDialog(null, "Record found at position: " + searchResult);
					} else {
						JOptionPane.showMessageDialog(null, "Record not found.");
					}
				}
				}

				break;
			}

			case 's':
			case 'S': {
				highScores.saveToFile();
				break;
			}

			default: {
				JOptionPane.showMessageDialog(null, "Unknown Command, Please Enter Again.");
			}

			}
		}
	}

}