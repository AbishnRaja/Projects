import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * 
 */

/**
 * @author Alvin
 * Date: March 2023
 * Description: This class shows an image as a component
 * Method List:
 * - void setimage(IconImage image)
 * - ImageIcon getImage()
 * - void paint(Graphics g)
 */
public class ImagePicture extends Picture{

	/**
	 * Private data (attributes)
	 */
	private ImageIcon image;
	
	/**
	 * Default constructor
	 */
	public ImagePicture(ImageIcon image) {
		// Initialise attributes
		super(); //calls default constructor of picture
		this.image = image;
		setmyWidth(image.getIconWidth());
		setmyHeight(image.getIconHeight());
	}
	
	/**
	 * Overloaded constructor
	 */
	public ImagePicture(ImageIcon image, int x, int y) {
		// Initialise attributes
		super(); //calls default constructor of picture
		this.image = image;
		setmyWidth(image.getIconWidth());
		setmyHeight(image.getIconHeight());
		setxPos(x);
		setyPos(y);
	}
	
	/**
	 * @param the image
	 */
	public void setImage(ImageIcon image) {
		this.image = image;
		// change image dimensions to new image
		setmyWidth(image.getIconWidth());
		setmyHeight(image.getIconHeight());
	}
	/**
	 * @return image
	 */
	public ImageIcon getImage() {
		return image;
	}
	
	/**
	 * paint method
	 */
	public void paint(Graphics g) {
		this.image.paintIcon(this, g, getxPos(), getyPos());
	}

	/**
	 * @param args
	 * Self testing main
	 */
	public static void main(String[] args) {
		// create a frame to paint on
		JFrame f = new JFrame();
		// create a new picture object
		ImagePicture p = new ImagePicture(new ImageIcon("B1BD.png"));

		// set the frame size
		f.setSize(900, 500);
		// add the object to the frame
		f.add(p);
		
		// show the frame with the picture
		f.setVisible(true);
		
		// show the dimensions of the picture object
		JOptionPane.showMessageDialog(null, "Width: " + p.getmyWidth() + "   Height: " + p.getmyHeight());
		
		// create a second picture object
		ImagePicture p1 = new ImagePicture(new ImageIcon("C3P0.png"), 100, 150);
		// add it to the frame
		f.add(p1);
		// show the frame with the new picture
		f.setVisible(true);
		
		// wait
		JOptionPane.showMessageDialog(null, "Wait!");
		// change the images
		p.setImage(new ImageIcon("R2D2.png"));
		p1.setImage(new ImageIcon("BB-8.png"));
		// show the second image
		f.repaint();
	}

}
