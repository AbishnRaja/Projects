import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 
 */

/**
 * @author Alvin
 * Date: May 2023
 * Description:
 * This class is the back-end logic for the chess program
 * Method List:
 * + Piece[] getPieces()
 * + void setPieces(Piece[] pieces)
 * + void setPieces(Piece pieces, int index) | sets the piece of the piece array for a certain index
 * + String getWinner()
 * + void setWinner(String winner)
 * + String getDate()
 * + String setDate(String date)
 * + int[] pieceAtTile() | Returns the piece index value (0-31) at a specific tile index value (0-63). Returns -1 if not found or out of range
 * + String toString() | Returns the board layout as a string 8x8 grid
 * + String getFilename(int index) | returns the image file name for a given piece
 * + String[] getMoves(int index) | return the tiles a piece can moves
 * + boolean hasMoves(char team) | returns whether if a team has moves or not
 * + int checkTile(int tile, char team) | checks if a tile is free, taken by opponent, or taken by same 
 * + static void main(String[] args) | self Testing
 * Resources:
 * - https://stackoverflow.com/questions/2399590/what-does-the-colon-operator-do
 * - https://stackoverflow.com/questions/31138533/what-is-the-easiest-way-to-get-the-current-date-in-basic-iso-8601-format-yyyymm
 */
public class Logic {

	// Attributes
	private Piece pieces[];
	private String winner;
	private String date;

	/**
	 * Default constructor
	 */
	public Logic() {
		// Initialise attributes
		pieces = new Piece[32];
		winner = "tie";
		// get the current date
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		date = dateFormat.format(new Date());

		// set the pieces and their placement
		pieces[0] = new Piece("rook", 'b', 0);
		pieces[1] = new Piece("knight", 'b', 1);
		pieces[2] = new Piece("bishop", 'b', 2);
		pieces[3] = new Piece("queen", 'b', 3);
		pieces[4] = new Piece("king", 'b', 4);
		pieces[5] = new Piece("bishop", 'b', 5);
		pieces[6] = new Piece("knight", 'b', 6);
		pieces[7] = new Piece("rook", 'b', 7);
		for(int i = 8; i < 16; i++) {
			pieces[i] = new Piece("pawn", 'b', i);
		}
		for(int i = 16; i < 24; i++) {
			pieces[i] = new Piece("pawn", 'w', i + 32);
		}
		pieces[24] = new Piece("rook", 'w', 56);
		pieces[25] = new Piece("knight", 'w', 57);
		pieces[26] = new Piece("bishop", 'w', 58);
		pieces[27] = new Piece("queen", 'w', 59);
		pieces[28] = new Piece("king", 'w', 60);
		pieces[29] = new Piece("bishop", 'w', 61);
		pieces[30] = new Piece("knight", 'w', 62);
		pieces[31] = new Piece("rook", 'w', 63);
	}

	/**
	 * Overloaded Constructor
	 * @param date
	 * @param board
	 * @param winner
	 */
	public Logic(String date, int[] board, String winner) {

		if(board.length >= 32) {
			this.date = date;
			this.winner = winner;
			pieces = new Piece[32];
			pieces[0] = new Piece("rook", 'b', board[0]);
			pieces[1] = new Piece("knight", 'b', board[1]);
			pieces[2] = new Piece("bishop", 'b', board[2]);
			pieces[3] = new Piece("queen", 'b', board[3]);
			pieces[4] = new Piece("king", 'b', board[4]);
			pieces[5] = new Piece("bishop", 'b', board[5]);
			pieces[6] = new Piece("knight", 'b', board[6]);
			pieces[7] = new Piece("rook", 'b', board[7]);
			for(int i = 8; i < 16; i++) {
				pieces[i] = new Piece("pawn", 'b', board[i]);
			}
			for(int i = 16; i < 24; i++) {
				pieces[i] = new Piece("pawn", 'w', board[i]);
			}
			pieces[24] = new Piece("rook", 'w', board[24]);
			pieces[25] = new Piece("knight", 'w', board[25]);
			pieces[26] = new Piece("bishop", 'w', board[26]);
			pieces[27] = new Piece("queen", 'w', board[27]);
			pieces[28] = new Piece("king", 'w', board[28]);
			pieces[29] = new Piece("bishop", 'w', board[29]);
			pieces[30] = new Piece("knight", 'w', board[30]);
			pieces[31] = new Piece("rook", 'w', board[31]);
		}
	}

	/**
	 * @return the pieces
	 */
	public Piece[] getPieces() {
		return pieces;
	}

	/**
	 * @param pieces the pieces to set
	 */
	public void setPieces(Piece[] pieces) {
		this.pieces = pieces;
	}

	/**
	 * Overloaded
	 * @param pieces the pieces to set at a specific index
	 */
	public void setPieces(Piece pieces, int index) {
		this.pieces[index] = pieces;
	}

	/**
	 * @return the winner
	 */
	public String getWinner() {
		return winner;
	}

	/**
	 * @param winner the winner to set
	 */
	public void setWinner(String winner) {
		this.winner = winner;
	}

	/**
	 * @return the date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * Method to find the piece at a certain tile
	 * @param tile
	 * @return
	 */
	public int pieceAtTile(int tile) {
		// look if input is in range
		if(tile >= 0 && tile < 64) {
			// check all pieces
			for(int i = 0; i < pieces.length; i++) {
				// if the tile is found, return the index
				if(pieces[i].getTile() == tile) {
					return i;
				}
			}
		}
		// return -1 if not found
		return -1;
	}

	/**
	 * Method to turn the pieces on a board into a string
	 */
	@Override
	public String toString() {
		// declare and initialise empty string variable
		String output = "";
		// loop 8 times
		for (int i = 0; i < 8; i++) {
			// loop 8 times
			for (int j = 0; j < 8; j++) {
				// if the piece at the tile has a valid piece
				if(this.pieceAtTile(i * 8 + j) > -1)
					// add the piece to the output
					output += this.pieceAtTile(i * 8 + j) + ",";
				else
					// add invalid piece
					output += -1 + ",";
			}
			// move to next line
			output += "\n";
		}
		// return the output
		return output;
	}


	/**
	 * @return the piece type image file name
	 */
	public String getFilename(int index) {
		// return the formatted filename as (team)(type).png. E.x: wpawn.png = white pawn
		return pieces[index].getTeam() + 
				pieces[index].getType() + ".png";
	}

	/**
	 * Method to return the tiles a piece may move
	 */
	public String[] getMoves(int index) {
		// check if the index is within the 32 pieces
		if(index > -1 && index <= pieces.length) {
			// declare and initialise variables
			String output = "";
			char team = pieces[index].getTeam();
			int tile = pieces[index].getTile();
			// calculate the possible moves if the tile is valid
			if(tile > -1) {
				switch(pieces[index].getType()) {
				case "pawn":{ // calculate pawn movement based on team
					if(team == 'w') {
						int check = checkTile(tile - 8, team);
						if(check > 1) {
							output += (tile - 8) + "/";
							if(!pieces[index].isHasMoved() && checkTile(tile - 16, team) > 1) {
								output += (tile - 16) + "/";
							}
						}
						if(tile%8 != 7 && checkTile(tile - 7, team) == 1) {
							output += (tile - 7) + "/";
						}
						if(tile%8 != 0 && checkTile(tile - 9, team) == 1) {
							output += (tile - 9) + "/";
						}
					}
					else {
						int check = checkTile(tile + 8, team);
						if(check > 1) {
							output += (tile + 8) + "/";
							if(!pieces[index].isHasMoved() && checkTile(tile + 16, team) > 1) {
								output += (tile + 16) + "/";
							}
						}
						if(tile%8 != 0 && checkTile(tile + 7, team) == 1) {
							output += (tile + 7) + "/";
						}
						if(tile%8 != 7 && checkTile(tile + 9, team) == 1) {
							output += (tile + 9) + "/";
						}
					}
					break;
				}
				case "rook":{
					for(int i = 1; i < 8; i++) {
						int check = checkTile(tile - i * 8, team);
						if(check > 0) {
							output += (tile - i * 8) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < 8; i++) {
						int check = checkTile(tile + i * 8, team);
						if(check > 0) {
							output += (tile + i * 8) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					//horizontal left
					for(int i = 1; i < 8; i++) {
						if((tile - i * 1)/8 < tile/8) {
							break;
						}

						int check = checkTile(tile - i * 1, team);
						if(check > 0) {
							output += (tile - i * 1) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}//horizontal right
					}
					for(int i = 1; i < 8; i++) {
						if((tile + i * 1)/8 > tile/8) 
							break;
						int check = checkTile(tile + i * 1, team);
						if(check > 0) {

							output += (tile + i * 1) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					break;
				}
				case "knight":{
					int column = tile%8;
					int skip = 0;
					switch(column) {
					case 0:{
						skip = 2;
						break;
					}
					case 1:{
						skip = 1;
						break;
					}
					case 6:{
						skip = 4;
						break;
					}
					case 7:{
						skip = 3;
					}
					}
					if(skip != 2) {
						if(checkTile(tile + 15, team) > 0) {
							output += (tile + 15) + "/";
						}
						if(checkTile(tile - 17, team) > 0) {
							output += (tile - 17) + "/";
						}
						if(skip != 1) {
							if(checkTile(tile - 10, team) > 0) {
								output += (tile - 10) + "/";
							}
							if(checkTile(tile + 6, team) > 0) {
								output += (tile + 6) + "/";
							}
						}
					}
					if(skip != 3) {
						if(checkTile(tile - 15, team) > 0) {
							output += (tile - 15) + "/";
						}
						if(checkTile(tile + 17, team) > 0) {
							output += (tile + 17) + "/";
						}
						if(skip != 4) {
							if(checkTile(tile - 6, team) > 0) {
								output += (tile - 6) + "/";
							}
							if(checkTile(tile + 10, team) > 0) {
								output += (tile + 10) + "/";
							}
						}
					}
					break;
				}
				case "bishop":{
					int left = tile%8 + 1, right = 9-left;
					for(int i = 1; i < left; i++) {
						int check = checkTile(tile + i * 7, team);
						if(check > 0) {
							output += (tile + i * 7) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < left; i++) {
						int check = checkTile(tile - i * 9, team);
						if(check > 0) {
							output += (tile - i * 9) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < right; i++) {
						int check = checkTile(tile + i * 9, team);
						if(check > 0) {
							output += (tile + i * 9) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < right; i++) {
						int check = checkTile(tile - i * 7, team);
						if(check > 0) {
							output += (tile - i * 7) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					break;
				}
				case "queen":{
					int left = tile%8 + 1, right = 9-left;
					for(int i = 1; i < left; i++) {
						int check = checkTile(tile + i * 7, team);
						if(check > 0) {
							output += (tile + i * 7) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < left; i++) {
						int check = checkTile(tile - i * 9, team);
						if(check > 0) {
							output += (tile - i * 9) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < right; i++) {
						int check = checkTile(tile + i * 9, team);
						if(check > 0) {
							output += (tile + i * 9) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < right; i++) {
						int check = checkTile(tile - i * 7, team);
						if(check > 0) {
							output += (tile - i * 7) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < 8; i++) {
						int check = checkTile(tile - i * 8, team);
						if(check > 0) {
							output += (tile - i * 8) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < 8; i++) {
						int check = checkTile(tile + i * 8, team);
						if(check > 0) {
							output += (tile + i * 8) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < 8; i++) {
						if((tile - i * 1)/8 < tile/8) {
							break;
						}
						int check = checkTile(tile - i * 1, team);
						if(check > 0) {
							output += (tile - i * 1) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					for(int i = 1; i < 8; i++) {
						if((tile + i * 1)/8 > tile/8) 
							break;
						int check = checkTile(tile + i * 1, team);
						if(check > 0) {

							output += (tile + i * 1) + "/";
							if(check == 1) {
								break;
							}
						}
						else {
							break;
						}
					}
					break;
				}
				default:{
					//king
					// declare and initialise variables
					int column = tile%8, skip = 0;
					// check the column the king is on and skip on certain columns
					switch(column) {
					case 0:{
						skip = 1;
						break;
					}
					case 7:{
						skip = 2;
						break;
					}
					}
					/**	
					 * look through top column for king
					 * 	[x][ ][ ]
					 *  [x][K][ ]
					 *  [x][ ][ ]
					 *  skip if on column 0
					 */
					if(skip != 1) {
						for(int i = 0; i < 3; i++) {
							// add if the tile is valid
							if(checkTile(tile - 9 + i * 8, team) > 0 && checkDetect(tile - 9 + i * 8, team).length == 0) {
								output += (tile - 9 + i * 8) + "/";
							}
						}
					}
					/**	
					 * look through middle row for king
					 * 	[ ][ ][x]
					 *  [ ][K][x]
					 *  [ ][ ][x]
					 *  skip if on column 7
					 */
					if(skip != 2) {
						for(int i = 0; i < 3; i++) {
							// add if the tile is valid
							if(checkTile(tile - 7 + i * 8, team) > 0 && checkDetect(tile - 7 + i * 8, team).length == 0) {
								output += (tile - 7 + i * 8) + "/";
							}
						}
					}
					/**	
					 * look through bottom row for king
					 * 	[ ][x][ ]
					 *  [ ][K][ ]
					 *  [ ][x][ ]
					 */
					for(int i = 0; i < 2; i++) {
						// add if the tile is valid
						if(checkTile(tile - 8 + i * 16, team) > 0 && checkDetect(tile - 8 + i * 16, team).length == 0) {
							output += (tile - 8 + i * 16) + "/";
						}
					}
				}
				}
			}
			// return a string array
			return output.split("/");
		}
		return new String[] {""};
	}

	/**
	 * Method to detect if there's potential check
	 * index 0:
	 * 0 = no check
	 * 1 = check
	 * index 1+:
	 * tiles that causes check
	 */
	public int[][] checkDetect(int tile, char team) {
		// declare and initialise output string variable
		String outStr = "";
		// declare boolean if king is safe
		boolean safe = true;
		// pawn detection
		int column = tile%8;
		int skip = 0;
		// pawn detection
		// skip detecting certain sides depending on king tile placement
		switch(column) {
		case 0:{
			skip = 1;
			break;
		}
		case 7:{
			skip = 2;
		}
		}
		if(team == 'w') {
			if(skip != 1) {
				// save the tile to check
				int checkTile = tile - 9;
				// if the tile is valid and has an opponent's piece, check if it's a pawn
				if(checkTile(checkTile, team) == 1) { 
					if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("pawn")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
				}
			}
			if(skip != 2) {
				// save the tile to check
				int checkTile = tile - 7;
				// if the tile had an opponent's piece, check if it's a pawn
				if(checkTile(checkTile, team) == 1) { 
					if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("pawn")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
				}
			}
		}
		else {
			if(skip != 1) {
				// save the tile to check
				int checkTile = tile + 9;
				// if the tile had an opponent's piece, check if it's a pawn
				if(checkTile(checkTile, team) == 1) { 
					if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("pawn")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
				}
			}
			if(skip != 2) {
				// save the tile to check
				int checkTile = tile + 7;
				// if the tile had an opponent's piece, check if it's a pawn
				if(checkTile(checkTile, team) == 1) { 
					if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("pawn")) {
						outStr += checkTile + "/";
					}
				}
			}
		}
		// divide for different type
		outStr += "//";
		// rook & queen detection
		// vertical up
		for(int i = 1; i < 8; i++) { // check up to 7 squares above
			// save the tile to check
			int checkTile = tile - i * 8;
			// end the loop if the tile is invalid
			if(checkTile < 0) {
				break;
			}
			// continue checking if the tile is valid
			if(checkTile(checkTile, team) != 0) {
				// if the tile had an opponent's piece, check if it's a queen or a rook
				if(checkTile(checkTile, team) == 1) {
					String type = getPieces()[pieceAtTile(checkTile)].getType();
					if(type.equalsIgnoreCase("rook") || type.equalsIgnoreCase("queen")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
					// end the loop
					break;
				}
			}
			else {
				// end the loop
				break;
			}
		}
		// vertical down
		for(int i = 1; i < 8; i++) { // check up to 7 squares below
			// save the tile to check
			int checkTile = tile + i * 8;
			// end the loop if the tile is invalid
			if(checkTile > 63) {
				break;
			}
			// continue checking if the tile is valid
			if(checkTile(checkTile, team) != 0) {
				// if the tile had an opponent's piece, check if it's a queen or a rook
				if(checkTile(checkTile, team) == 1) {
					String type = getPieces()[pieceAtTile(checkTile)].getType();
					if(type.equalsIgnoreCase("rook") || type.equalsIgnoreCase("queen")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
					// end the loop
					break;
				}
			}
			else {
				// end the loop
				break;
			}
		}
		// horizontal left
		for(int i = 1; i < 8; i++) {
			// save the tile to check
			int checkTile = tile - i;
			// end the loop if the tile changes row or if invalid
			if(checkTile < 0 || checkTile/8 < tile/8) {
				break;
			}
			// continue checking if the tile is valid
			if(checkTile(checkTile, team) != 0) {
				// if the tile had an opponent's piece, check if it's a queen or a rook
				if(checkTile(checkTile, team) == 1) {
					String type = getPieces()[pieceAtTile(checkTile)].getType();
					if(type.equalsIgnoreCase("rook") || type.equalsIgnoreCase("queen")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
					// end the loop
					break;
				}
			}
			else {
				// end the loop
				break;
			}
		}
		// horizontal right
		for(int i = 1; i < 8; i++) {
			// save the tile to check
			int checkTile = tile + i;
			// end the loop if the tile changes row or if invalid
			if(tile < 0 || checkTile/8 < tile/8) {
				break;
			}
			// continue checking if the tile is valid
			if(checkTile(checkTile, team) != 0) {
				// if the tile had an opponent's piece, check if it's a queen or a rook
				if(checkTile(checkTile, team) == 1) {
					String type = getPieces()[pieceAtTile(checkTile)].getType();
					if(type.equalsIgnoreCase("rook") || type.equalsIgnoreCase("queen")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
					// end the loop
					break;
				}
			}
			else {
				// end the loop
				break;
			}
		}
		// divide for different type
		outStr += "//";
		// bishop & queen detection
		// declare and initialise variables
		int left = tile%8 + 1, right = 9-left;
		// diagonal bottom left
		for(int i = 1; i < left; i++) {
			int checkTile = tile + i * 7;
			// continue checking if the tile is valid
			if(checkTile(checkTile, team) != 0) {
				// if the tile had an opponent's piece, check if it's a queen or a bishop
				if(checkTile(checkTile, team) == 1) {
					String type = getPieces()[pieceAtTile(checkTile)].getType();
					if(type.equalsIgnoreCase("queen") || type.equalsIgnoreCase("bishop")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
					// end the loop
					break;
				}
			}
		}
		// diagonal top left
		for(int i = 1; i < left; i++) {
			int checkTile = tile - i * 9;
			// continue checking if the tile is valid
			if(checkTile(checkTile, team) != 0) {
				// if the tile had an opponent's piece, check if it's a queen or a bishop
				if(checkTile(checkTile, team) == 1) {
					String type = getPieces()[pieceAtTile(checkTile)].getType();
					if(type.equalsIgnoreCase("queen") || type.equalsIgnoreCase("bishop")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
					// end the loop
					break;
				}
			}
		}
		// diagonal bottom right
		for(int i = 1; i < right; i++) {
			int checkTile = tile + i * 9;
			// continue checking if the tile is valid
			if(checkTile(checkTile, team) != 0) {
				// if the tile had an opponent's piece, check if it's a queen or a bishop
				if(checkTile(checkTile, team) == 1) {
					String type = getPieces()[pieceAtTile(checkTile)].getType();
					if(type.equalsIgnoreCase("queen") || type.equalsIgnoreCase("bishop")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
					// end the loop
					break;
				}
			}
		}
		// diagonal top right
		for(int i = 1; i < right; i++) {
			int checkTile = tile - i * 7;
			// continue checking if the tile is valid
			if(checkTile(checkTile, team) != 0) {
				// if the tile had an opponent's piece, check if it's a queen or a bishop
				if(checkTile(checkTile, team) == 1) {
					String type = getPieces()[pieceAtTile(checkTile)].getType();
					if(type.equalsIgnoreCase("queen") || type.equalsIgnoreCase("bishop")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
					// end the loop
					break;
				}
			}
		}
		// divide for different type
		outStr += "//";
		// knight detection
		skip = 0;
		switch(column) {
		case 0:{
			skip = 2;
			break;
		}
		case 1:{
			skip = 1;
			break;
		}
		case 6:{
			skip = 4;
			break;
		}
		case 7:{
			skip = 3;
		}
		}
		if(skip != 2) {
			int checkTile = tile + 15;
			if(checkTile(checkTile, team) == 1) {
				if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("knight")) {
					// set safe false and leave code block
					safe = false;
					outStr += checkTile + "/";
				}
			}
			checkTile = tile - 17;
			if(checkTile(checkTile, team) == 1) {
				if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("knight")) {
					// set safe false and leave code block
					safe = false;
					outStr += checkTile + "/";
				}
			}
			if(skip != 1) {
				checkTile = tile - 10;
				if(checkTile(checkTile, team) == 1) {
					if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("knight")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
				}
				checkTile = tile + 6;
				if(checkTile(checkTile, team) == 1) {
					if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("knight")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
				}
			}
		}
		if(skip != 3) {
			int checkTile = tile - 15;
			if(checkTile(checkTile, team) == 1) {
				if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("knight")) {
					// set safe false and leave code block
					safe = false;
					outStr += checkTile + "/";
				}
			}
			checkTile = tile + 17;
			if(checkTile(checkTile, team) == 1) {
				if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("knight")) {
					// set safe false and leave code block
					safe = false;
					outStr += checkTile + "/";
				}
			}
			if(skip != 4) {
				checkTile = tile + 10;
				if(checkTile(checkTile, team) == 1) {
					if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("knight")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
				}
				checkTile = tile - 6;
				if(checkTile(checkTile, team) == 1) {
					if(getPieces()[pieceAtTile(checkTile)].getType().equalsIgnoreCase("knight")) {
						// set safe false and leave code block
						safe = false;
						outStr += checkTile + "/";
					}
				}
			}
		}
		// check for king detection if tile is not under threat
		if(safe) {
			// create label
			safe : {
				// king detection
				skip = 0;
				// skip certain movement on certain columns
				switch(column) {
				case 0:{
					skip = 1;
					break;
				}
				case 7:{
					skip = 2;
					break;
				}
				}
				/**	
				 * look through top column for king
				 * 	[x][ ][ ]
				 *  [x][K][ ]
				 *  [x][ ][ ]
				 */
				if(skip != 1) {
					for(int i = 0; i < 3; i++) {
						// save the tile to check
						int checkTile = tile - 9 + i * 8;
						// skip to next tile if the tile is invalid
						if(checkTile > 0) {
							continue;
						}
						// continue checking if the tile is valid
						if(checkTile(checkTile, team) != 0) {
							// if the tile had an opponent's piece, check if it's a queen or a rook
							if(checkTile(checkTile, team) == 1) {
								String type = getPieces()[pieceAtTile(checkTile)].getType();
								if(type.equalsIgnoreCase("king")) {
									// set safe false and leave code block
									safe = false;
									break safe;
								}
								// end the loop
								break;
							}
						}
					}
				}
				/**	
				 * look through middle row for king
				 * 	[ ][ ][x]
				 *  [ ][K][x]
				 *  [ ][ ][x]
				 */
				if(skip != 2) {
					for(int i = 0; i < 3; i++) {
						// save the tile to check
						int checkTile = tile - 7 + i * 8;
						// skip to next tile if the tile is invalid
						if(checkTile > 0) {
							continue;
						}
						// continue checking if the tile is valid
						if(checkTile(checkTile, team) != 0) {
							// if the tile had an opponent's piece, check if it's a queen or a rook
							if(checkTile(checkTile, team) == 1) {
								String type = getPieces()[pieceAtTile(checkTile)].getType();
								if(type.equalsIgnoreCase("king")) {
									// set safe false and leave code block
									safe = false;
									break safe;
								}
								// end the loop
								break;
							}
						}
					}
				}
				/**	
				 * look through bottom row for king
				 * 	[ ][x][ ]
				 *  [ ][K][ ]
				 *  [ ][x][ ]
				 */
				for(int i = 0; i < 2; i++) {
					// save the tile to check
					int checkTile = tile - 8 + i * 16;
					// skip to next tile if the tile is invalid
					if(checkTile > 0) {
						continue;
					}
					// continue checking if the tile is valid
					if(checkTile(checkTile, team) != 0) {
						// if the tile had an opponent's piece, check if it's a queen or a rook
						if(checkTile(checkTile, team) == 1) {
							String type = getPieces()[pieceAtTile(checkTile)].getType();
							if(type.equalsIgnoreCase("king")) {
								// set safe false and leave code block
								safe = false;
								break safe;
							}
							// end the loop
							break;
						}
					}
				}
			}
		}
		// return only 0 if safe
		if(safe) {
			return new int[0][];
		}
		// declare and initialise array variable for output
		String[] outArray = outStr.split("//");
		int[][] output = new int[outArray.length][];
		for(int i = 1; i < output.length; i++) {
			String[] moves = outArray[i].split("/");
			output[i] = new int[moves.length];
			// add all string elements as integers
			if(moves.length > 0 && moves[0] != "" ) {
				for(int j = 0; j < moves.length; j++) {
					output[i][j] = Integer.parseInt(moves[j]);
				}
			}
		}
		return output;
	}

	/**
	 * Method to see if a team has any possible moves left
	 */
	public boolean hasMoves(char team) {
		// check team
		if(team == 'b') {
			for(int i = 0; i < 16; i++) {
				// save the moves
				String[] moves = getMoves(i);
				// check every pieces' moves
				if(moves.length > 0 && moves[0] != "") {
					// return true if a piece has a possible move
					return true;
				}
			}
		}
		else {
			for(int i = 16; i < 32; i++) {
				// check every pieces' moves
				if(getMoves(i)[0] != "") {
					// return true if a piece has a possible move
					return true;
				}
			}
		}
		// return false is there wasn't a possible move
		return false;
	}

	/**
	 * Method to check if a piece can go to a square
	 * 0 = invalid move
	 * 1 = take opponent's piece
	 * 2 = free space
	 */
	public int checkTile(int tile, char team) {
		if(tile < 0 || tile > 63) { // return 0 if tile is out of range
			return 0;
		}
		// if the tile has a piece, check the piece's team
		if(pieceAtTile(tile) > -1) {
			if(pieces[pieceAtTile(tile)].getTeam() == team) {
				// return 0 if the team is the same
				return 0;
			}
			// return 1 for other team
			return 1;
		}
		// return 2 for free space
		return 2;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// declare and initialise logic object and set all of its attributes
		Logic l1 = new Logic();
		Piece[] pieces = new Piece[32];
		for(int i = 0; i < pieces.length; i++) {
			pieces[i] = new Piece("pawn", ' ', i * 2);
		}
		l1.setPieces(pieces);
		// get all pieces and print their attributes
		Piece[] outPieces1 = l1.getPieces();
		for(int i = 0; i < outPieces1.length; i++) {
			System.out.println("Piece " + i + ": " + outPieces1[i].getType() + " " + outPieces1[i].getTeam() + " " + outPieces1[i].getTile());
		}
		// set and get the winner and date to print
		l1.setDate("1234/56/78");
		System.out.println(l1.getDate());
		l1.setWinner("The friends we made along the way!");
		System.out.println(l1.getWinner());
		// declare and initialise integer array for input
		int[] p1 = {63,62,61,60,59,58,57,56,55,54,53,52,51,50,48,47,15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0};
		// declare and initialise logic object with overloaded constructor
		Logic l2 = new Logic("Today", p1, "Me");
		// print the new logic's attributes
		// get all pieces and print their attributes
		Piece[] outPieces2 = l2.getPieces();
		for(int i = 0; i < outPieces2.length; i++) {
			System.out.println("Piece " + i + ": " + outPieces2[i].getType() + " " + outPieces2[i].getTeam() + " " + outPieces2[i].getTile());
		}
		System.out.println(l2.getDate());
		System.out.println(l2.getWinner());
	}

}
