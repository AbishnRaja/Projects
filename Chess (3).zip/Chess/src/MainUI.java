import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * 
 */

/**
 * @author Alvin
 * Date: June 2023
 * Description: This class is the main ui for the chess game
 * Method List:
 * + static void main(String[] args) | Self testing
 * + void actionPerformed (ActionEvent e) | Gets called when an action is performed
 */
public class MainUI extends JFrame implements ActionListener{
	private JButton btnpvc, btnpvp, btnhelp, btnscores;
	private FileAccess help;
	private HighScoreUI scores;

	/**
	 * Default constructor
	 */
	public MainUI() {
		// call the default constructor of the JFrame class
		super();
		// set the dimensions and component layout style
		setSize(600, 450);
		setLayout(null);
		// create, size, locate, and add buttons and add their actionListeners
		btnpvc = new JButton("Single Player");
		btnpvc.setBounds(44,330,120,40);
		add(btnpvc);
		btnpvc.addActionListener(this);
		btnpvp = new JButton("Multiplayer");
		btnpvp.setBounds(208,330,120,40);
		add(btnpvp);
		btnpvp.addActionListener(this);
		btnhelp = new JButton("Help");
		btnhelp.setBounds(372,330,60,40);
		add(btnhelp);
		btnhelp.addActionListener(this);
		btnscores = new JButton("Scores");
		btnscores.setBounds(476,330,80,40);
		add(btnscores);
		btnscores.addActionListener(this);
		// initialise remaining attributes
		help = new FileAccess("help.txt");

		// show window
		setVisible(true);
		// make window not resizable
		setResizable(false);
		// properly end program when x is pressed
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	/**
	 * @param args Self Testing
	 */
	public static void main(String[] args) {
		// Create ui object
		MainUI ui = new MainUI();
	}

	// method for actions events
	public void actionPerformed (ActionEvent e){
		if(e.getSource() == btnpvc) { // person vs computer is selected
			// close ui window and open chess with ai
			this.dispose();
			new Chess();
		}
		else if(e.getSource() == btnpvp) { // person vs person is selected
			// close ui window and open chess without ai
			this.dispose();
			new ChessAI();
		}
		else if(e.getSource() == btnhelp) { // help button
			// open help window
			help.print();
		}
		else if(e.getSource() == btnscores) { // highscore button
			// open highscore ui
			scores = new HighScoreUI();
		}
	}
}
