import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * @author Alvin
 * Date: March 2023
 * Description: This class draws a simple picture as a component
 * Method List:
 * - int getxPos()
 * - void setxPos(int xPos)
 * - int getyPos()
 * - void setyPos(int yPos)
 * - int getmyWidth()
 * - void setmyWidth(int myWidth)
 * - int getmyHeight()
 * - void setmyHeight(int myHeight)
 * - void setColour(Color colour)
 * - void paint(Graphics g)
 */
public class Picture extends JComponent {
	
	/*
	 * Attributes or private data
	 */
	private Color colour;
	private int xPos, yPos, myWidth, myHeight;
	
	/**
	 * Default constructor
	 */
	public Picture() {
		// initialise the attributes
		this.colour = new Color(100,255,100);
		this.xPos = 0;
		this.yPos = 0;
		this.myWidth = 50;
		this.myHeight = 50;
		
	}
	/**
	 * Overloaded constructor
	 */
	public Picture(int x, int y) {
		// initialise the attributes
		this.colour = Color.red;
		this.xPos = x;
		this.yPos = y;
		this.myWidth = 50;
		this.myHeight = 50;
		
	}
	
	/**
	 * @return the xPos
	 */
	public int getxPos() {
		return xPos;
	}

	/**
	 * @param xPos the xPos to set
	 */
	public void setxPos(int xPos) {
		this.xPos = xPos;
	}

	/**
	 * @return the yPos
	 */
	public int getyPos() {
		return yPos;
	}

	/**
	 * @param yPos the yPos to set
	 */
	public void setyPos(int yPos) {
		this.yPos = yPos;
	}

	/**
	 * @return the myWidth
	 */
	public int getmyWidth() {
		return myWidth;
	}

	/**
	 * @param myWidth the myWidth to set
	 */
	public void setmyWidth(int myWidth) {
		this.myWidth = myWidth;
	}

	/**
	 * @return the myHeight
	 */
	public int getmyHeight() {
		return myHeight;
	}

	/**
	 * @param myHeight the myHeight to set
	 */
	public void setmyHeight(int myHeight) {
		this.myHeight = myHeight;
	}

	/**
	 * @param colour the colour to set
	 */
	public void setColour(Color colour) {
		this.colour = colour;
	}

	// paint method
	public void paint (Graphics g) {
		g.setColor(this.colour);
		g.fillRect(this.xPos, this.yPos, this.myWidth, this.myHeight);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// testing
		JFrame f = new JFrame("Title");
		f.setSize(400, 350); // size the frame
		Picture p = new Picture(); // create and add picture to the frame
		f.add(p);
		f.setVisible(true); // show the frame
		JOptionPane.showMessageDialog(null, "Wait!"); // add pop-up to separate individual frames 
		p.setColour(Color.BLUE); // change the colour to blue and repaint the JFrame
		f.repaint();
		
		JOptionPane.showMessageDialog(null, "Wait!"); // add pop-up to separate individual frames
		p.setColour(new Color(50,50,120)); // change the colour to RGB values
		f.repaint();
		 
		JOptionPane.showMessageDialog(null, "Wait!"); // add pop-up to separate individual frames
		p.setxPos(p.getxPos()+20); // move 20px to the right
		p.setyPos(p.getmyHeight()+100); // move 100px down
		f.repaint(); // show the picture
		
		JOptionPane.showMessageDialog(null, "Wait!"); // add pop-up to separate individual frames
		p.setmyWidth(p.getmyWidth()/2); // change width to half its current width
		p.setmyHeight(p.getmyHeight()*2); // change height to double its current height
		f.repaint(); // show the picture
		
		JOptionPane.showMessageDialog(null, "Wait"); // add pop-up to separate individual frames
		Picture p1 = new Picture(200, 50); // create a new picture object
		f.add(p1); // add the new object to the frame and show it
		f.setVisible(true);
		
		JOptionPane.showMessageDialog(null, "Wait!"); // add pop-up to separate individual frames
		p1.setxPos(0); // move the x value of to new picture object to px 0 and show the new picture
		f.repaint();
	}
	public Color getColour() {
		return colour;
	}
}
