/**
 * 
 */

/**
 * @author Alvin
 * Date: May 2023
 * Description:
 * Object class of a piece
 * Method List:
 * 
 */
public class Piece {
	// Attributes
	private String type;
	private char team;
	private int tile;
	private boolean hasMoved;
	
	/**
	 * Default constructor
	 */
	public Piece() {
		// initialise attributes
		type = "";
		team = 0;
		tile = -1;
		hasMoved = false;
	}
	
	/**
	 * Overloaded constructor
	 */
	public Piece(String type, char team, int tile) {
		// initialise attributes
		this.type = type;
		this.team = team;
		this.tile = tile;
		hasMoved = false;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the team
	 */
	public char getTeam() {
		return team;
	}

	/**
	 * @param team the team to set
	 */
	public void setTeam(char team) {
		this.team = team;
	}

	/**
	 * @return the tile
	 */
	public int getTile() {
		return tile;
	}

	/**
	 * @param tile the tile to set
	 */
	public void setTile(int tile) {
		this.tile = tile;
	}

	/**
	 * @return the hasMoved
	 */
	public boolean isHasMoved() {
		return hasMoved;
	}

	/**
	 * @param hasMoved the hasMoved to set
	 */
	public void setHasMoved(boolean hasMoved) {
		this.hasMoved = hasMoved;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Creates a piece Object
		Piece piece = new Piece();
		
		// Sets All The Attributes
		piece.setTeam('w');
		piece.setType("Pawn");
		piece.setTile(42);
		piece.setHasMoved(true);
	
		// Gets All The Attributes
		piece.getTeam();
		piece.getTile();
		piece.getType();
	}

}
