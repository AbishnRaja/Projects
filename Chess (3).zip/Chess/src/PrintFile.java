import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * 
 */

/**
 * @author Alvin
 * Date: June 2023
 * Description: This class prints a window with data from a file
 *
 */
public class PrintFile extends JFrame{

	// Private Attributes
	private JScrollPane scroll;
	private JTextArea text;

	/**
	 * Default constructor
	 */
	public PrintFile(String contents) {
		// call parent class' default constructor
		super();
		// set the window dimensions
		setSize(400,300);
		// add the contents to the text area, then add the text are to the scroll pane
		text = new JTextArea(contents);
		text.setFont(new Font("monospaced", Font.BOLD, 14));
		scroll = new JScrollPane(text);
		add(scroll);
		// show window
		setVisible(true);
		// make window not sizeable
		setResizable(false);
		// properly end program when x is pressed
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	/**
	 * @param args Self Testing
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new PrintFile("TEST1\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nTEST TEST TEST TEST TEST TEST TEST TEST TEST TEST TEST TEST");
	}

}
